import { Component, OnInit } from '@angular/core';
import { isError } from 'util';
import { Router } from '@angular/router';
import { HarcodedAuthenticationService } from '../service/harcoded-authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit 
{
  username="ajinkyab"
  password="dummy"
  errorMessage="Invalid credentials !!!!!"
  isError =false;

  // We are using Angular's in built dependency injection to inject Router.
  // here we do not have to define router as a instance variable. If we define in
  // constructor, angular will consider this to be a instance variable
  constructor(private router: Router,private hardcodedAuthenticationService:HarcodedAuthenticationService) { }

  ngOnInit() {
  }

  handleLogin()
  {
    console.log(this.username)
    console.log(this.password)

    // some basic validations
    if(this.hardcodedAuthenticationService.authenticate(this.username,this.password))
    {
      sessionStorage.setItem("authenticateUser",this.username)
      this.isError = false
      // routing to welcome component
      this.router.navigate(['welcome',this.username])
    }
    else 
      this.isError = true
    }

    isUserLoggedIn()
    {
      let user = sessionStorage.getItem("authenticateUser")

      return !(user===null)
    }
}
