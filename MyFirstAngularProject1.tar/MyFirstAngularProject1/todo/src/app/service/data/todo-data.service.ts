import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';



export class Todo
{

  constructor(private id: number,private username: String,private description:String,private targetDate:Date,private isDone:boolean){  }
}
@Injectable({
  providedIn: 'root'
})


export class TodoDataService {

   name:String = 'ajinkyab'

  constructor(private httpClient: HttpClient) { }



getTodoList(name)
{
  console.log('sending name:' + name);
  // We need to subscribe without which angular will not invoke the url (as it is asynchronous, 
  // some one has to subscribe it first)
  return this.httpClient.get<Todo[]>(`http://localhost:8080/users/${name}/todo`);
}

deleteTodo(id)
{
  console.log('Deleting Todo item :' + id);
  // We need to subscribe without which angular will not invoke the url (as it is asynchronous, 
  // some one has to subscribe it first)
  return this.httpClient.delete(`http://localhost:8080/users/${name}/todos/${id}`);
}

}