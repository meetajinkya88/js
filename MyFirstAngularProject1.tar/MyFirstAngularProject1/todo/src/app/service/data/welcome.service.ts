import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class HelloWorldBean
{

  constructor(private message: String){  }
}

@Injectable({
  providedIn: 'root'
})



export class WelcomeService {

  constructor(private httpClient: HttpClient) { }


getHelloWorldBeanService(name)
{
  console.log('sending name:' + name);
  // We need to subscribe without which angular will not invoke the url (as it is asynchronous, 
  // some one has to subscribe it first)
  return this.httpClient.get<HelloWorldBean>(`http://localhost:8080/helloWorldBean/pathVaribale/${name}`);
}

}