import { Injectable } from '@angular/core';

// below annotations signifies that this service is injectable in all the components
@Injectable({
  providedIn: 'root'
})
export class HarcodedAuthenticationService {

  constructor() { }

  authenticate(username:string,password:string)
  {
    return username==="ajinkyab" && password==="dummy"
  }
  
  isUserLoggedIn()
    {
      let user = sessionStorage.getItem("authenticateUser")

      return !(user===null)
    }
  logout()
  {
    sessionStorage.removeItem("authenticateUser")
  }
}
