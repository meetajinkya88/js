import { Component, OnInit } from '@angular/core';
import { HarcodedAuthenticationService } from '../service/harcoded-authentication.service';
import { TodoDataService, Todo } from '../service/data/todo-data.service';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})


export class TodoListComponent implements OnInit 
{
  private todoList : Todo[];
  // private todoList = [
  //   new todo(1,"Learn DS",new Date,false),
  //   new todo(2,"Learn Algo",new Date,false),
  //   new todo(3,"Learn Angular",new Date,false)
  // ];
  username : string = "ggg"
  deleteMessage : string =""

  constructor(private todoDataService:TodoDataService, private route: ActivatedRoute) { }
//private route: ActivatedRoute,
  ngOnInit() : void {


    this.refreshTodoList();
  }

  refreshTodoList()
  {
    // this is how we need to parse the path parameters
    this.username = this.route.snapshot.params['username'];
    console.log("TodoComponent" + this.username)

     this.todoDataService.getTodoList(this.username).subscribe(

      response=> {  this.todoList = response

      }

     )
  }
  deleteTodo(id)
  {
    this.todoDataService.deleteTodo(this.username,id).subscribe(

      response=> {  this.deleteMessage = `Delete Successful for item ${id}`      }
    )
    this.refreshTodoList();


  }

}
